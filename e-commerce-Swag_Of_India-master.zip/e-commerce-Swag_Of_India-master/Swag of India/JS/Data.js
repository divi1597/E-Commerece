let shopItemsData = [{
    id: "a1",
    name: "Awesome Product 1",
    price: "2748",
    priceAfterDiscount: "1649",
    img: "./img/Home-page/product1.png"
},
{
    id: "a2",
    name: "Cool Product 2",
    price: "2998",
    priceAfterDiscount: "1799",
    img: "./img/Home-page/product2.png"

},
{
    id: "a3",
    name: "Amazing Product 3",
    price: "3978",
    priceAfterDiscount: "2387",
    img: "./img/Home-page/product3.png"
}
]